const inputBox = document.getElementById("input-box");
const listContainer = document.getElementById("list-container");
const addButton = document.getElementById("add-button");

// Load tasks from backend when page loads
window.onload = function () {
    loadTasks();
};

async function loadTasks() {
    const response = await fetch('/api/tasks');
    const tasks = await response.json();
    listContainer.innerHTML = ''; // Clear existing
    tasks.forEach(task => renderTask(task));
}

// Add new task using API
async function addTask(title) {
    const response = await fetch('/api/tasks', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title })
    });
    const newTask = await response.json();
    renderTask(newTask);
}

// Render task DOM element
function renderTask(task) {
    let li = document.createElement("li");
    li.textContent = task.title;
    li.dataset.id = task.id;
    if (task.completed) li.classList.add("checked");
    listContainer.appendChild(li); 

    let span = document.createElement("span");
    span.innerHTML = "\u00d7";
    li.appendChild(span);
}

// Handle click on Add button
addButton.addEventListener("click", function () {
    const title = inputBox.value.trim();
    if (title !== "") {
        addTask(title);
        inputBox.value = "";
    } else {
        alert("Please enter a task");
    }
});

// Handle Enter key
inputBox.addEventListener("keydown", function (event) {
    if (event.key === "Enter") {
        const title = inputBox.value.trim();
        if (title !== "") {
            addTask(title);
            inputBox.value = "";
        } else {
            alert("Please enter a task");
        }
    }
});

// Clicks: toggle or delete
listContainer.addEventListener("click", function (e) {
    if (e.target.tagName === "LI") {
        const li = e.target;
        const id = li.dataset.id;

        // Call PUT API to toggle completion
        fetch(`/api/tasks/${id}/toggle`, {
            method: 'PUT'
        })
        .then(response => response.json())
        .then(updatedTask => {
            if (updatedTask.completed) {
                li.classList.add("checked");
            } else {
                li.classList.remove("checked");
            }
        });
    } else if (e.target.tagName === "SPAN") {
        const li = e.target.parentElement;
        const id = li.dataset.id;

        // Call DELETE API
        fetch(`/api/tasks/${id}`, {
            method: 'DELETE'
        }).then(() => {
            li.remove();
        });
    }
}, false); 

const clearButton = document.getElementById("clear-all");

clearButton.addEventListener("click", () => {
    if (confirm("Are you sure you want to clear all tasks?")) {
        fetch('/api/tasks', {
            method: 'DELETE'
        }).then(() => {
            listContainer.innerHTML = '';
        });
    }
});
